import cv2
import glob
import numpy as np

for i in range(9):
    #import pdb; pdb.set_trace()
    name = 'table%03d'%(i+1)
    for f in glob.glob('%s/renders/*'%name):
        img = cv2.imread(f)
        mask = cv2.imread(f.replace('/renders/','/mask/'),0)
        new_mask = np.ones(mask.shape)*255
        new_mask[mask==0]=255
        new_mask[mask==255]=0
        
        save_img_path = 'C:/Users/Doris Lee/Desktop/ObjectMatching/Image-Synthesis-for-Machine-Learning-master/data/train/diningtable/img/'
        save_mask_path = 'C:/Users/Doris Lee/Desktop/ObjectMatching/Image-Synthesis-for-Machine-Learning-master/data/train/diningtable/mask/'
        save_name = f.split('renders')[1][1:]
        cv2.imwrite('%s%s_%s'%(save_img_path,name,save_name),img)
        cv2.imwrite('%s%s_%s'%(save_mask_path,name,save_name),mask)
        import pdb; pdb.set_trace()